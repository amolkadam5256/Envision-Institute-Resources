import React, { useState } from "react";
import { Link } from "react-router-dom";

export const Navigation = () => {
  const [isNavOpen, setIsNavOpen] = useState(false);

  return (
    <nav id="menu" className="navbar navbar-default navbar-fixed-top">
      <div className="container">
        <div className="navbar-header">
          {/* Mobile Navbar Toggle Button */}
          <button
            type="button"
            className="navbar-toggle collapsed"
            onClick={() => setIsNavOpen(!isNavOpen)}
          >
            <span className="sr-only">Toggle navigation</span>
            <span className="icon-bar"></span>
            <span className="icon-bar"></span>
            <span className="icon-bar"></span>
          </button>

          {/* Brand Link */}
          <Link className="navbar-brand" to="/">
            Amol
          </Link>
        </div>

        {/* Navigation Links */}
        <div className={`collapse navbar-collapse ${isNavOpen ? "in" : ""}`}>
          <ul className="nav navbar-nav navbar-right">
            <li><Link to="/" onClick={() => setIsNavOpen(false)}>Home</Link></li>
            <li><Link to="/features" onClick={() => setIsNavOpen(false)}>Features</Link></li>
            <li><Link to="/about" onClick={() => setIsNavOpen(false)}>About</Link></li>
            <li><Link to="/services" onClick={() => setIsNavOpen(false)}>Services</Link></li>
            <li><Link to="/portfolio" onClick={() => setIsNavOpen(false)}>Gallery</Link></li>
            <li><Link to="/testimonials" onClick={() => setIsNavOpen(false)}>Testimonials</Link></li>
            <li><Link to="/team" onClick={() => setIsNavOpen(false)}>Team</Link></li>
            <li><Link to="/contact" onClick={() => setIsNavOpen(false)}>Contact</Link></li>
          </ul>
        </div>
      </div>
    </nav>
  );
};
