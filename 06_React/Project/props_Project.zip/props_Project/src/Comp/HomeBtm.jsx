import React from 'react';

const HomeBtm = () => {
    return (
        <div className="position-relative start-50 translate-middle-x custom-top">
            <div className="arrow d-flex justify-content-center align-items-center">
                <i className="bi bi-chevron-double-down"></i>
            </div>
        </div>
    );
}

export default HomeBtm;
